const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Candidate = require('../models/candidate');

dotenv.config();

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        const result = await Candidate.updateMany(
            { electionType: 'state', state: { $exists: false } },
            { $set: { state: 'Gujarat' } }
        );
        console.log(`Updated ${result.modifiedCount} candidates!`);

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
