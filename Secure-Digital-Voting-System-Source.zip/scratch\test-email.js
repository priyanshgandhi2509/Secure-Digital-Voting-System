const nodemailer = require('nodemailer');
const dotenv = require('dotenv');

dotenv.config();

async function run() {
    try {
        console.log("Initializing transporter with env credentials...");
        console.log(`EMAIL_USER: ${process.env.EMAIL_USER}`);
        // Mask password
        const pass = process.env.EMAIL_PASS || '';
        const maskedPass = pass.substring(0, 3) + '*'.repeat(Math.max(0, pass.length - 3));
        console.log(`EMAIL_PASS: ${maskedPass}`);

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });

        console.log("Attempting to send a test email to prachiapatel2702@gmail.com...");
        const info = await transporter.sendMail({
            from: `"Vooting Test" <${process.env.EMAIL_USER}>`,
            to: "prachiapatel2702@gmail.com",
            subject: "SMTP Connection Test",
            text: "This is a secure connection test from your Vooting Application."
        });

        console.log("✅ SUCCESS! Email sent successfully!");
        console.log("Message ID:", info.messageId);
    } catch (err) {
        console.log("❌ SMTP AUTHENTICATION FAILED!");
        console.log("Exact Error Details:");
        console.error(err);
    }
}

run();
