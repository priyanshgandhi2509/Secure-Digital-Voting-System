const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Candidate = require('../models/candidate');
const candidateController = require('../controllers/candidateController');

dotenv.config();

// Create mock req and res
function createMockReqRes(body, params, onDone) {
  return {
    req: {
      body,
      params,
      user: { id: new mongoose.Types.ObjectId().toString() }, // Pass mock admin user id
      ip: '127.0.0.1',
      app: { get: () => null }
    },
    res: {
      statusCode: 200,
      responseData: null,
      status: function(code) {
        this.statusCode = code;
        return this;
      },
      json: function(data) {
        this.responseData = data;
        if (onDone) onDone(data);
        return this;
      }
    }
  };
}

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        // Find a candidate
        const candidate = await Candidate.findOne({ electionType: 'state' });
        if (!candidate) {
            console.log("No state candidate found!");
            await mongoose.disconnect();
            return;
        }

        console.log(`Original Candidate: ${candidate.name}, State: ${candidate.state}`);

        const testState = "Maharashtra";
        console.log(`Updating state to ${testState}...`);

        await new Promise((resolve, reject) => {
            const { req, res } = createMockReqRes({
                name: candidate.name,
                party: candidate.party,
                age: candidate.age,
                electionType: 'state',
                state: testState
            }, { candidateID: candidate._id.toString() }, (responseData) => {
                console.log("Response JSON callback received:", JSON.stringify(responseData, null, 2));
                resolve();
            });

            candidateController.updateCandidate(req, res, (err) => {
                if (err) {
                    console.error("Express next() called with error:", err);
                    reject(err);
                }
            });
        });

        // Fetch updated candidate from DB to confirm
        const updated = await Candidate.findById(candidate._id);
        console.log(`Updated Candidate in DB: ${updated.name}, State: ${updated.state}`);

        if (updated.state === testState) {
            console.log("✅ SUCCESS: Dynamic candidate update works perfectly!");
        } else {
            console.log("❌ ERROR: Candidate update failed!");
        }

        // Restore back to Gujarat
        await Candidate.findByIdAndUpdate(candidate._id, { state: "Gujarat" });

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
