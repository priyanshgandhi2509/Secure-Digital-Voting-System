const { GoogleGenerativeAI } = require("@google/generative-ai");
const fs = require('fs');

async function test() {
  const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  try {
    // We will just prompt it to see if it allows this
    const result = await model.generateContent([
      "Are these two images of the same person? Answer YES or NO.",
      // Provide dummy images or see if it blocks based on text alone
    ]);
    console.log(result.response.text());
  } catch (err) {
    console.error("Error:", err.message);
  }
}
test();
