const Election = require('../models/election');
const AuditLog = require('../models/auditLog');
const ApiError = require('../utils/ApiError');
const ApiResponse = require('../utils/ApiResponse');
const catchAsync = require('../utils/catchAsync');

const createElection = catchAsync(async (req, res) => {
  if (req.body.status === 'active') {
    const activeElection = await Election.findOne({ status: 'active' });
    if (activeElection) {
      throw new ApiError(400, "Cannot start a new election while another election is currently active. Please complete the active election first.");
    }
  }
  const election = await Election.create(req.body);
  await AuditLog.create({ action: 'CREATE_ELECTION', userId: req.user.id, details: { electionId: election._id } });
  res.status(201).json(new ApiResponse(201, election, "Election created successfully"));
});

const getElectionStatus = catchAsync(async (req, res) => {
  const election = await Election.findOne().sort({ createdAt: -1 }); // Get latest election
  if (!election) {
    throw new ApiError(404, "No active election configured");
  }
  res.status(200).json(new ApiResponse(200, election, "Election status retrieved"));
});

const updateElection = catchAsync(async (req, res) => {
  const { status, startTime, endTime, electionType, activeState } = req.body;
  
  if (status === 'active') {
    // Find the latest election that will be updated
    const electionToUpdate = await Election.findOne().sort({ createdAt: -1 });
    
    // If there is an election to update, and it is not already active
    if (electionToUpdate && electionToUpdate.status !== 'active') {
      const activeElection = await Election.findOne({ status: 'active' });
      if (activeElection) {
        throw new ApiError(400, "Cannot start a new election while another election is currently active. Please complete the active election first.");
      }
    }
  }

  const election = await Election.findOneAndUpdate({}, { status, startTime, endTime, electionType, activeState }, { returnDocument: 'after', upsert: true, setDefaultsOnInsert: true, runValidators: true, sort: { createdAt: -1 } });
  
  await AuditLog.create({ action: 'UPDATE_ELECTION', userId: req.user.id, details: { electionId: election._id, status } });
  res.status(200).json(new ApiResponse(200, election, "Election updated successfully"));
});

module.exports = {
  createElection,
  getElectionStatus,
  updateElection
};
