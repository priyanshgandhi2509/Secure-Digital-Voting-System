const mongoose = require('mongoose');

const electionSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    default: "General Election"
  },
  status: {
    type: String,
    enum: ['upcoming', 'active', 'completed'],
    default: 'upcoming'
  },
  startTime: {
    type: Date
  },
  endTime: {
    type: Date
  },
  electionType: {
    type: String,
    enum: ['national', 'state'],
    default: 'national'
  },
  activeState: {
    type: String, // E.g., 'Gujarat'. Matters if type is 'state' or 'city'
    default: null
  },
  activeCity: {
    type: String, // E.g., 'Surat'. Only matters if electionType is 'city'
    default: null
  }
}, { timestamps: true });

const Election = mongoose.models.Election || mongoose.model('Election', electionSchema);
module.exports = Election;
