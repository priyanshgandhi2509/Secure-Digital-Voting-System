const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.resolve(__dirname, '../public/locations.js'), 'utf-8');
const lines = content.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('Rajastan')) {
    console.log(`Line ${i+1}: ${lines[i]}`);
    console.log("Surrounding lines:");
    for (let j = Math.max(0, i-5); j <= Math.min(lines.length-1, i+5); j++) {
      console.log(`${j+1}: ${lines[j]}`);
    }
  }
}
process.exit(0);
