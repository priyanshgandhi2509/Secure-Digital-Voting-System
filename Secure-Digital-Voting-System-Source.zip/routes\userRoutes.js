const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const userController = require('../controllers/userController');
const { jwtAuthMiddleware } = require('../middlewares/authMiddleware');

router.post('/signup', [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('age').isInt({ min: 18 }).withMessage('Must be at least 18 years old to vote'),
  body('aadharCardNumber').trim().isLength({ min: 12, max: 12 }).isNumeric().withMessage('Aadhar Card must be exactly 12 digits'),
  body('password').trim().isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
  body('state').notEmpty().withMessage('State is required'),
  body('address').trim().notEmpty().withMessage('Address is required')
], userController.signup);

router.post('/login', userController.login);
router.put('/profile/password', jwtAuthMiddleware, userController.updatePassword);
router.post('/request-otp', jwtAuthMiddleware, userController.requestOTP);

module.exports = router;