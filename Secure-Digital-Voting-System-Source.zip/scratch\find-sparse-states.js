const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.resolve(__dirname, '../public/locations.js'), 'utf-8');
const data = eval(content + "\nindiaLocations;");

for (const [state, cities] of Object.entries(data)) {
  console.log(`${state}: ${cities.length} cities`);
}
process.exit(0);
