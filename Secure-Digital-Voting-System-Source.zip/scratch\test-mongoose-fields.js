const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Candidate = require('../models/candidate');

dotenv.config();

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        console.log("Candidate Schema Paths:");
        console.log(Object.keys(Candidate.schema.paths));

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
