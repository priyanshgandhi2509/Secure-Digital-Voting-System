const express = require('express');
const router = express.Router();
const electionController = require('../controllers/electionController');
const { jwtAuthMiddleware } = require('../middlewares/authMiddleware');
const { isAdmin } = require('../middlewares/roleMiddleware');

router.get('/status', electionController.getElectionStatus); // public
router.post('/', jwtAuthMiddleware, isAdmin, electionController.createElection);
router.put('/', jwtAuthMiddleware, isAdmin, electionController.updateElection);

module.exports = router;
