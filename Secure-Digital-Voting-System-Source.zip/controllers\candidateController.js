const Candidate = require('../models/candidate');
const User = require('../models/user');
const Election = require('../models/election');
const AuditLog = require('../models/auditLog');
const ApiError = require('../utils/ApiError');
const ApiResponse = require('../utils/ApiResponse');
const catchAsync = require('../utils/catchAsync');
const { Parser } = require('json2csv');
const VoteLedger = require('../models/voteLedger');
const OTP = require('../models/otp');
const crypto = require('crypto');

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", 
  "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", 
  "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", 
  "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands", 
  "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu", "Lakshadweep", "Delhi", "Puducherry", "Ladakh", "Jammu and Kashmir"
];

const sendEmail = require('../utils/emailService');

const simulateExternalNotification = async (email, mobile, message) => {
  console.log(`\n===================`);
  console.log(`[EXTERNAL_SMS] Sent to ${mobile}: ${message}`);
  if (email) {
    await sendEmail(
      email, 
      "Vooting - Vote Confirmation", 
      message,
      `<div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
        <h2 style="color: #28a745;">Vote Confirmed!</h2>
        <p>${message}</p>
        <div style="background: #f8f9fa; padding: 10px; border-radius: 4px; border: 1px dashed #ccc;">
          <strong>Security Tip:</strong> You strictly get one vote per election. This record is locked in the digital ledger.
        </div>
       </div>`
    );
  }
  console.log(`===================\n`);
};

const addCandidate = catchAsync(async (req, res) => {
  const newCandidate = new Candidate(req.body);
  const savedCandidate = await newCandidate.save();

  await AuditLog.create({ action: 'CREATE_CANDIDATE', userId: req.user.id, details: { candidateName: savedCandidate.name } });

  res.status(201).json(new ApiResponse(201, savedCandidate, "Candidate added successfully"));
});

const updateCandidate = catchAsync(async (req, res) => {
  const { candidateID } = req.params;

  const response = await Candidate.findByIdAndUpdate(
    candidateID,
    req.body,
    { returnDocument: 'after', runValidators: true }
  );

  if (!response) {
    throw new ApiError(404, "Candidate not found");
  }

  await AuditLog.create({ action: 'UPDATE_CANDIDATE', userId: req.user.id, details: { candidateId: candidateID, updates: req.body } });

  res.status(200).json(new ApiResponse(200, response, "Candidate updated successfully"));
});

const deleteCandidate = catchAsync(async (req, res) => {
  const { candidateID } = req.params;

  const response = await Candidate.findByIdAndDelete(candidateID);

  if (!response) {
    throw new ApiError(404, "Candidate not found");
  }

  await AuditLog.create({ action: 'DELETE_CANDIDATE', userId: req.user.id, details: { candidateId: candidateID } });

  res.status(200).json(new ApiResponse(200, null, "Candidate deleted successfully"));
});

const voteForCandidate = catchAsync(async (req, res) => {
  const { candidateID } = req.params;
  const { otp, liveFaceDescriptor } = req.body;
  const userId = req.user.id;

  if (!otp) {
    throw new ApiError(400, "Verification code (OTP) is required to vote");
  }

  // 1) Verify Active Election Constraints
  const election = await Election.findOne().sort({ createdAt: -1 });
  if (!election || election.status !== 'active') {
    throw new ApiError(403, "Voting is currently closed or not yet active");
  }

  // 2) OTP Verification
  const otpRecord = await OTP.findOne({ userId, otp, type: 'voting' });
  if (!otpRecord || otpRecord.expiresAt < new Date()) {
    throw new ApiError(400, "Invalid or expired OTP");
  }

  // 3) Normal Validation
  const candidate = await Candidate.findById(candidateID);
  if (!candidate) throw new ApiError(404, "Candidate not found");

  const user = await User.findById(userId);
  if (!user) throw new ApiError(404, "User not found");

  if (user.isVoted) throw new ApiError(400, "You have already voted");
  if (user.role === 'admin') throw new ApiError(403, "Admins are not allowed to vote");

  // Face Verification Check
  if (user.faceDescriptor && user.faceDescriptor.length > 0) {
    if (!liveFaceDescriptor || liveFaceDescriptor.length !== user.faceDescriptor.length) {
      throw new ApiError(400, "Live face verification failed. Missing or invalid live face data.");
    }
    
    // Calculate Euclidean distance to the logged-in user's face
    let sum = 0;
    for (let i = 0; i < user.faceDescriptor.length; i++) {
      const diff = user.faceDescriptor[i] - liveFaceDescriptor[i];
      sum += diff * diff;
    }
    const distance = Math.sqrt(sum);
    
    // face-api.js default threshold is 0.6
    if (distance > 0.6) {
      throw new ApiError(403, "Face verification failed. The live photo does not match the registration photo.");
    }

    // Strict Check: Make sure the live face doesn't match any OTHER registered user's face (which belongs to a different Aadhar card)
    const otherUsers = await User.find({ _id: { $ne: userId }, faceDescriptor: { $exists: true, $ne: [] } });
    for (const otherUser of otherUsers) {
      if (otherUser.faceDescriptor && otherUser.faceDescriptor.length === liveFaceDescriptor.length) {
        let otherSum = 0;
        for (let i = 0; i < otherUser.faceDescriptor.length; i++) {
          const diff = otherUser.faceDescriptor[i] - liveFaceDescriptor[i];
          otherSum += diff * diff;
        }
        const otherDistance = Math.sqrt(otherSum);
        if (otherDistance <= 0.6) {
          throw new ApiError(403, `Face verification failed. This face matches the photo of a different Aadhar Card (${otherUser.aadharCardNumber.substring(0, 8)}XXXX) and is not applicable for this vote.`);
        }
      }
    }
  }

  // Verify Election constraints against User's data
  if (election.electionType === 'state') {
     if (candidate.electionType !== 'state') {
        throw new ApiError(403, "A State election is currently active. You cannot vote for a National candidate.");
     }
     if (election.activeState && election.activeState.toLowerCase() !== user.state.toLowerCase()) {
        throw new ApiError(403, `You are not applicable for voting. Currently, only the ${election.activeState} state election is active.`);
     }
  } else if (election.electionType === 'national') {
      if (candidate.electionType !== 'national') {
          throw new ApiError(403, "A National election is currently active. You cannot vote for a State candidate.");
      }
  } else if (election.electionType === 'city') {
      if (candidate.electionType !== 'city') {
          throw new ApiError(403, "A City election is currently active. You cannot vote for other candidates.");
      }
      if (election.activeCity && election.activeCity.toLowerCase() !== user.city.toLowerCase()) {
        throw new ApiError(403, `You are not applicable for voting. Currently, only the ${election.activeCity} city election is active.`);
     }
  }

  // 4) Anomaly Detection (Simulated)
  const recentVotesFromIP = await AuditLog.countDocuments({
    action: 'VOTE_CAST',
    ipAddress: req.ip,
    createdAt: { $gt: new Date(Date.now() - 60000) } // Last 1 minute
  });
  if (recentVotesFromIP > 5) {
    throw new ApiError(429, "Suspicious activity detected from your network. Please wait.");
  }

  // 5) Ledger Integrity (Blockchain-lite)
  const lastBlock = await VoteLedger.findOne().sort({ createdAt: -1 });
  const previousHash = lastBlock ? lastBlock.hash : "0000000000000000000000000000000000000000000000000000000000000000";
  const timestamp = new Date();
  const currentHash = VoteLedger.calculateHash(userId, candidateID, previousHash, timestamp);
  const signature = crypto.createHmac('sha256', process.env.JWT_SECRET || 'fallback_secret')
    .update(`${userId}-${candidateID}-${timestamp.toISOString()}`)
    .digest('hex');

  await VoteLedger.create({ voterId: userId, candidateId: candidateID, previousHash, hash: currentHash, timestamp, signature });

  // 6) Record Vote & Cleanup
  candidate.votes.push({ User: userId, voterState: user.state, voterCity: user.city });
  candidate.voteCount++;
  await candidate.save();

  user.isVoted = true;
  await user.save();
  await OTP.deleteMany({ userId }); // Burn used OTPs

  // 7) Audit Log
  await AuditLog.create({
    action: 'VOTE_CAST',
    userId: userId,
    ipAddress: req.ip,
    details: { candidateId: candidateID, transactionHash: currentHash }
  });

  // 8) WebSockets broadcast
  const io = req.app.get("io");
  if (io) {
    io.emit("liveVoteUpdate", {
      candidateId: candidate._id,
      newCount: candidate.voteCount,
      party: candidate.party,
      voterDemographics: { age: user.age, city: user.city, state: user.state },
      verifiedAt: timestamp
    });
  }

  simulateExternalNotification(user.email, user.mobile, `Success! Your vote has been linked to the digital audit trail. Hash: ${currentHash.substring(0, 8)}...`);

  res.status(200).json(new ApiResponse(200, { transactionHash: currentHash }, "Vote secured and recorded successfully"));
});

const getVoteCount = catchAsync(async (req, res) => {
  const { type } = req.query;
  const filter = {};
  if (type && ['national', 'state', 'city'].includes(type)) {
    filter.electionType = type;
  }

  const candidates = await Candidate.find(filter).sort({ voteCount: 'desc' });

  const voteRecord = candidates.map(data => ({
    party: data.party,
    count: data.voteCount,
    electionType: data.electionType
  }));

  res.status(200).json(new ApiResponse(200, voteRecord, "Vote count retrieved successfully"));
});

const getResultsStats = catchAsync(async (req, res) => {
  const candidates = await Candidate.find();
  const uniqueStates = await User.distinct('state');

  const totalGlobalVotes = candidates.reduce((acc, curr) => acc + curr.voteCount, 0);

  const stateWiseResults = uniqueStates.map(stateName => {
    const partyResults = candidates.map(candidate => {
      const count = candidate.votes.filter(v => v.voterState === stateName).length;
      return {
        party: candidate.party,
        candidateName: candidate.name,
        votes: count
      };
    });

    return { state: stateName, results: partyResults };
  });

  res.status(200).json(new ApiResponse(200, { totalGlobalVotes, stateWiseResults }, "Result stats retrieved"));
});

const getResults = catchAsync(async (req, res) => {
  const { type } = req.query; // national or state

  if (!type || (type !== 'national' && type !== 'state' && type !== 'city')) {
    throw new ApiError(400, "Invalid or missing type. Use 'national', 'state' or 'city'");
  }

  // Find all candidates for the given election type (case-insensitive)
  const candidates = await Candidate.find({ 
    electionType: { $regex: new RegExp(`^${type}$`, 'i') } 
  });

  // If no candidates, return empty list
  if (!candidates || candidates.length === 0) {
    return res.status(200).json(new ApiResponse(200, [], `${type} results retrieved (no candidates)`));
  }

  if (type === 'national') {
    // Always use all Indian states as the base to ensure full searchability
    const states = INDIAN_STATES;
    
    const result = states.map(stateName => {
      const stateResults = candidates.map(c => ({
        party: c.party,
        candidateName: c.name,
        votes: c.votes.filter(v => 
          (v.voterState || '').toLowerCase().trim() === (stateName || '').toLowerCase().trim()
        ).length
      }));

      // Calculate total votes in this state
      const totalStateVotes = stateResults.reduce((acc, curr) => acc + curr.votes, 0);

      // Only return states with actual votes
      return totalStateVotes > 0 ? {
        location: stateName,
        totalVotes: totalStateVotes,
        results: stateResults.sort((a, b) => b.votes - a.votes)
      } : null;
    }).filter(item => item !== null)
    .sort((a, b) => b.totalVotes - a.totalVotes);

    return res.status(200).json(new ApiResponse(200, result, "National state-wise results retrieved"));
  }

  if (type === 'state') {
    const { state: targetState } = req.query;
    
    // Get unique city-state pairs from users, filtering out blanks
    const cityStatePairs = await User.aggregate([
      { 
        $match: { 
          state: targetState ? { $regex: new RegExp(`^${targetState}$`, 'i') } : { $nin: [null, ""] },
          city: { $nin: [null, ""] }
        } 
      },
      { $group: { _id: { city: "$city", state: "$state" } } }
    ]);
    
    const result = cityStatePairs.map(pair => {
      const cityName = pair._id.city;
      const stateName = pair._id.state;

      const cityResults = candidates.map(c => ({
        party: c.party,
        candidateName: c.name,
        votes: c.votes.filter(v => 
          (v.voterCity || '').toLowerCase().trim() === (cityName || '').toLowerCase().trim() &&
          (v.voterState || '').toLowerCase().trim() === (stateName || '').toLowerCase().trim()
        ).length
      }));

      const totalCityVotes = cityResults.reduce((acc, curr) => acc + curr.votes, 0);

      return {
        location: cityName,
        parentState: stateName,
        totalVotes: totalCityVotes,
        results: cityResults.sort((a, b) => b.votes - a.votes)
      };
    }).filter(item => item !== null)
    .sort((a, b) => b.totalVotes - a.totalVotes);

    return res.status(200).json(new ApiResponse(200, result, targetState ? `Results for ${targetState} city-wise` : "State-wise results retrieved"));
  }

  if (type === 'city') {
    const { city: targetCity } = req.query;
    
    const usersWithCity = await User.find({
      city: targetCity ? { $regex: new RegExp(`^${targetCity}$`, 'i') } : { $nin: [null, ""] }
    }).distinct('city');

    const result = await Promise.all(usersWithCity.map(async (cityName) => {
      const cityResults = candidates.map(c => ({
        party: c.party,
        candidateName: c.name,
        votes: c.votes.filter(v => 
          (v.voterCity || '').toLowerCase().trim() === cityName.toLowerCase().trim()
        ).length
      }));

      const totalCityVotes = cityResults.reduce((acc, curr) => acc + curr.votes, 0);

      return totalCityVotes > 0 ? {
        location: cityName,
        totalVotes: totalCityVotes,
        results: cityResults.sort((a, b) => b.votes - a.votes)
      } : null;
    }));

    const finalResult = result.filter(item => item !== null).sort((a, b) => b.totalVotes - a.totalVotes);

    return res.status(200).json(new ApiResponse(200, finalResult, targetCity ? `Results for city: ${targetCity}` : "City-wise results retrieved"));
  }
});


const exportResultsCSV = catchAsync(async (req, res) => {
  const candidates = await Candidate.find().sort({ voteCount: 'desc' });
  const records = candidates.map(c => ({
    CandidateName: c.name,
    Party: c.party,
    TotalVotesReceived: c.voteCount,
    ElectionType: c.electionType
  }));

  const parser = new Parser();
  const csvData = parser.parse(records);

  res.header('Content-Type', 'text/csv');
  res.attachment('election_end_results.csv');
  return res.send(csvData);
});

const getAllCandidates = catchAsync(async (req, res) => {
  const candidates = await Candidate.find({}, '_id name party age electionType state city');
  res.status(200).json(new ApiResponse(200, candidates, "All candidates retrieved successfully"));
});

const verifyLedger = catchAsync(async (req, res) => {
  const blocks = await VoteLedger.find().sort({ createdAt: 1 });

  let isValid = true;
  const discrepancies = [];

  for (let i = 0; i < blocks.length; i++) {
    const current = blocks[i];
    const previous = i > 0 ? blocks[i - 1] : null;

    // 1. Verify previous hash link
    if (previous && current.previousHash !== previous.hash) {
      isValid = false;
      discrepancies.push({ index: i, error: "Previous hash mismatch", blockId: current._id });
    }

    // 2. Re-calculate and verify current hash
    const reCalculatedHash = VoteLedger.calculateHash(
      current.voterId,
      current.candidateId,
      current.previousHash,
      current.timestamp
    );

    if (reCalculatedHash !== current.hash) {
      isValid = false;
      discrepancies.push({ index: i, error: "Hash tampering detected", blockId: current._id });
    }
  }

  res.status(200).json(new ApiResponse(200, { isValid, totalBlocks: blocks.length, discrepancies }, "Ledger integrity verification completed"));
});

// Global AI Cache
let cachedPrediction = null;
let lastPredictionTimestamp = 0;
const CACHE_DURATION = 30 * 60 * 1000;

const getAIPrediction = catchAsync(async (req, res) => {
  const { GoogleGenerativeAI } = require("@google/generative-ai");
  const apiKey = process.env.GOOGLE_API_KEY;

  // 1. Cache Check
  if (cachedPrediction && (Date.now() - lastPredictionTimestamp < CACHE_DURATION)) {
    console.log("[AI_SYSTEM] Returning cached prediction");
    return res.status(200).json(new ApiResponse(200, { prediction: cachedPrediction }, "Success (Cached)"));
  }

  // 2. Fetch Data
  let candidates = [];
  try {
    candidates = await Candidate.find({}, 'name party voteCount').sort({ voteCount: 'desc' });
  } catch (dbErr) {
    console.log("[AI_INFO] Database busy, using empty set for forecast");
  }

  const top = candidates[0] || { name: "Leading Candidates", party: "Major Parties", voteCount: 0 };
  const next = candidates[1] || { name: "Opposition", party: "Minor Parties", voteCount: 0 };

  // 3. Try AI
  let aiText = null;
  if (apiKey) {
    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      const prompt = `Analyze these election trends and provide a 4-paragraph 5-year forecast:
      ${candidates.map(c => `${c.name} (${c.party}): ${c.voteCount} votes`).join('\n')}`;

      const result = await model.generateContent(prompt);
      aiText = result.response.text();
      console.log("[AI_SYSTEM] Gemini Flash Success");
    } catch (aiErr) {
      console.log("[AI_INFO] AI Quota hit. Using Local Heuristic Engine.");
    }
  }

  // 4. Guaranteed Fallback Analysis
  if (!aiText) {
    aiText = `Our high-speed analysis shows ${top.name} (${top.party}) is currently setting the pace with ${top.voteCount} votes. This indicates a significant shift in voter sentiment towards their proposed digital-first policies.

Over the next 5 years, we anticipate a major focus on infrastructure revitalization and economic stabilization. The current leadership gap suggests a clear mandate for the upcoming term.

While ${next.name} maintains a competitive edge in several regions, the central momentum is undeniably in favor of the current leader. Expect bold legislative moves in the first 18 months of the new term.

(Note: This is a Smart Fallback Analysis generated locally to ensure 100% uptime).`;
  }

  // 5. Update Cache & Return
  cachedPrediction = aiText;
  lastPredictionTimestamp = Date.now();

  return res.status(200).json(new ApiResponse(200, { prediction: aiText }, "Forecast generated successfully"));
});

const aiChat = catchAsync(async (req, res) => {
  const { GoogleGenerativeAI } = require("@google/generative-ai");
  const apiKey = process.env.GOOGLE_API_KEY;
  const { prompt: userPrompt } = req.body;

  if (!userPrompt) {
    throw new ApiError(400, "Message is required");
  }

  // Fetch data context
  const candidates = await Candidate.find({}, 'name party voteCount').sort({ voteCount: 'desc' });
  const top = candidates[0] || { name: "Leading Candidates", party: "Major Parties", voteCount: 0 };
  const context = candidates.map(c => `${c.name} (${c.party}): ${c.voteCount} votes`).join('\n');

  let aiResponse = null;

  if (apiKey) {
    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      
      const systemPrompt = `You are an expert Political Analyst and Election Assistant with access to real-time ground sentiment from our voting app and extensive knowledge of Indian politics.
      
      GUIDELINES:
      1. REAL-WORLD DATA: Use your internal knowledge of Indian political history, current state-wise/city-wise trends (BJP, INC, AAP, etc.), and regional dynamics (as of 2024-2026 ground reality).
      2. FORECASTS: When asked about the next 5 years (e.g., 2027-2030), provide realistic forecasts based on actual political performance, anti-incumbency, and regional coalitions, NOT just the live votes in this app.
      3. CITY-SPECIFIC: If a user asks about a specific city or state (e.g., "Who will win in Mumbai?"), provide a detailed analysis based on that city's political leaning and major issues.
      4. APP CONTEXT: Acknowledge the "Live App Sentiment" (provided below) as a data point, but prioritize real-world logic for broader questions.
      5. FORMATTING: Use clear, professional, and engaging language. Avoid purely numeric answers; provide context.

      LIVE APP SENTIMENT (Use as reference for this app's current user base):
      ${context}

      User Question: ${userPrompt}`;

      const result = await model.generateContent(systemPrompt);
      aiResponse = result.response.text();
    } catch (err) {
      console.log("[AI_CHAT] Gemini failed:", err.message);
      console.error(err);
      console.log("[AI_CHAT] Using static fallback context.");
    }
  }

  if (!aiResponse) {
    const lowerPrompt = userPrompt.toLowerCase();
    
    const states = ["andhra pradesh", "arunachal pradesh", "assam", "bihar", "chhattisgarh", "goa", "gujarat", "haryana", "himachal pradesh", "jharkhand", "karnataka", "kerala", "madhya pradesh", "maharashtra", "manipur", "meghalaya", "mizoram", "nagaland", "odisha", "punjab", "rajasthan", "sikkim", "tamil nadu", "telangana", "tripura", "uttar pradesh", "uttarakhand", "west bengal", "delhi", "jammu and kashmir", "ladakh", "puducherry"];
    
    const majorCities = ["mumbai", "delhi", "bangalore", "hyderabad", "ahmedabad", "chennai", "kolkata", "surat", "pune", "jaipur", "lucknow", "kanpur", "nagpur", "indore", "thane", "bhopal", "visakhapatnam", "pimpri-chinchwad", "patna", "vadodara", "ghaziabad", "ludhiana", "agra", "nashik", "faridabad", "meerut", "rajkot", "kalyan-dombivli", "vasai-virar", "varanasi", "srinagar", "aurangabad", "dhanbad", "amritsar", "navi mumbai", "prayagraj", "howrah", "ranchi", "gwalior", "jabalpur", "coimbatore", "vijayawada", "jodhpur", "madurai", "raipur", "chandigarh", "guwahati", "solapur", "hubli-dharwad", "mysore", "tiruchirappalli", "bareilly", "aligarh", "tiruppur", "gurgaon", "moradabad", "jalandhar", "bhubaneswar", "salem", "warangal", "guntur", "bhiwandi", "saharanpur", "gorakhpur", "bikaner", "amravati", "noida", "jamshedpur", "bhilai", "cuttack", "firozabad", "kochi", "nellore", "bhavnagar", "dehradun", "durgapur", "asansol", "rourkela", "nanded", "kolhapur", "ajmer", "akola", "gulbarga", "jamnagar", "ujjain", "loni", "siliguri", "jhansi", "ulhasnagar", "nellore", "jammu", "sangli-miraj & kupwad", "belgaum", "mangalore", "ambattur", "tirunelveli", "malegaon", "gaya", "jalgaon", "udaipur", "maheshtala"];

    let detectedLocation = states.find(s => lowerPrompt.includes(s)) || majorCities.find(c => lowerPrompt.includes(c));
    let displayLoc = detectedLocation ? detectedLocation.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : "this region";

    // Extract Year
    let yearMatch = userPrompt.match(/\d{4}/);
    let displayYear = yearMatch ? yearMatch[0] : "2027";

    // Smart Fallback Engine 3.0 (Comprehensive)
    if (detectedLocation) {
        aiResponse = `Analyzing the political landscape for ${displayLoc}... In the ${displayYear} election horizon, ${displayLoc} is expected to be a critical pivot point. While app sentiment currently shows support for ${top.party}, the real-world ground reality in ${displayLoc} suggests that voter behavior will be driven by localized development, infrastructure stability, and regional leadership performance. Historical trends indicate a high-stakes contest for ${displayLoc} by the time we reach ${displayYear}.`;
    } else if (lowerPrompt.includes('winner') || lowerPrompt.includes('win')) {
        aiResponse = `Regarding the ${displayYear} outcome: Current app data favors ${top.name} (${top.party}). However, analysts suggest that the actual winner in ${displayYear} will depend on how major national parties manage state-level alliances and address the evolving needs of the 18-25 voter demographic.`;
    } else {
        aiResponse = `The ${displayYear} forecast for India suggests a trend of "Performance-Based Voting." While ${top.party} leads in our live app sentiment, the broader 5-year outlook across various states indicates that economic reforms and digital transparency will be the ultimate deciding factors for voters in ${displayYear}.`;
    }
  }

  res.status(200).json(new ApiResponse(200, { response: aiResponse }, "Chat response generated"));
});

module.exports = {
  addCandidate,
  updateCandidate,
  deleteCandidate,
  voteForCandidate,
  getVoteCount,
  getResultsStats,
  getResults,
  exportResultsCSV,
  getAllCandidates,
  verifyLedger,
  getAIPrediction,
  aiChat
};
