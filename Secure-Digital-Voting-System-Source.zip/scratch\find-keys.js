const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.resolve(__dirname, '../public/locations.js'), 'utf-8');
const data = eval(content + "\nindiaLocations;");

for (const key of Object.keys(data)) {
  if (key.toLowerCase().includes('raja')) {
    console.log("Found key:", key);
  }
}
process.exit(0);
