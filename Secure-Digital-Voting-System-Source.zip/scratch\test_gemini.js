const { GoogleGenerativeAI } = require('@google/generative-ai');
const dotenv = require('dotenv');
dotenv.config();

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

async function test() {
    try {
        const models = await genAI.listModels();
        console.log("Available models (first 5):");
        console.log(models.models.slice(0, 5).map(m => m.name));
        
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const result = await model.generateContent("test");
        console.log("Gemini 1.5 Flash check: SUCCESS");
    } catch (error) {
        console.error("ERROR TYPE:", error.name);
        console.error("ERROR MESSAGE:", error.message);
        if (error.response) {
            console.error("RESPONSE STATUS:", error.response.status);
        }
    }
}

test();
