const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URL).then(async () => {
    try {
        await require('./models/candidate').updateMany({}, { $set: { votes: [], voteCount: 0 } });
        await require('./models/user').updateMany({}, { $set: { isVoted: false } });
        console.log('Database voting state completely reset!');
    } catch (err) {
        console.error(err);
    }
    process.exit(0);
});
