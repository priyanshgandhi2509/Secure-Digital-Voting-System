const jwt = require('jsonwebtoken');
const ApiError = require('../utils/ApiError');
const catchAsync = require('../utils/catchAsync');

const jwtAuthMiddleware = catchAsync(async (req, res, next) => {
  const authorization = req.headers.authorization;

  if (!authorization) {
    throw new ApiError(401, "Token Not Found");
  }

  const token = authorization.split(" ")[1];

  if (!token) {
    throw new ApiError(401, "Unauthorized");
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // The user object set in token payload (e.g. { id: userId })
    next();
  } catch (err) {
    console.error("JWT Error:", err.message);
    throw new ApiError(401, "Invalid or Expired Token");
  }
});

const generateToken = (userData) => {
  if (!process.env.JWT_SECRET) {
    throw new Error("JWT_SECRET is missing in .env");
  }
  return jwt.sign(userData, process.env.JWT_SECRET, { expiresIn: "7d" });
};

module.exports = { jwtAuthMiddleware, generateToken };
