const signupData = {
  name: "Test User",
  age: 22,
  aadharCardNumber: "987654321012",
  password: "password123",
  state: "Gujarat",
  city: "Ahmedabad",
  address: "123 Test St",
  email: "testuser@example.com",
  mobile: "9876543210",
  faceDescriptor: Array(128).fill(0.1),
  photo: "data:image/jpeg;base64,xxxx"
};

console.log("Sending signup request...");
fetch("http://localhost:3000/api/v1/user/signup", {
  method: "POST",
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify(signupData)
})
.then(async (res) => {
  const data = await res.json();
  console.log("Status:", res.status);
  console.log("Response:", JSON.stringify(data, null, 2));
})
.catch((err) => {
  console.error("Error:", err);
});
