const fs = require('fs');
const path = require('path');

const content = fs.readFileSync(path.resolve(__dirname, '../public/locations.js'), 'utf-8');
const lines = content.split('\n');

const states = ["Arunachal Pradesh", "Meghalaya", "Mizoram", "Nagaland", "Sikkim"];
for (const state of states) {
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes(`"${state}":`)) {
      console.log(`${state}: Line ${i+1}`);
      for (let j = i; j <= i + 10; j++) {
        console.log(`  ${j+1}: ${lines[j]}`);
        if (lines[j].includes(']')) break;
      }
    }
  }
}
process.exit(0);
