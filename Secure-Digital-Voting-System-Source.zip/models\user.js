const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Define the Person schema
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  age: {
    type: Number,
    required: true
  },
  mobile: {
    type: String
  },
  email: {
    type: String,
  },
  address: {
    type: String,
    required: true
  },
  aadharCardNumber: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  role: {
    type: String,
    enum: ['voter', 'admin'],
    default: 'voter'
  },
  password: {
    required: true,
    type: String
  },
  isVoted: {
    type: Boolean,
    default: false
  },
  state: { 
    type: String, 
    required: true 
  },
  city: {
    type: String,
    required: false
  },
  faceDescriptor: {
    type: [Number], // 128-dimensional array from face-api.js
    required: false
  },
  photo: {
    type: String, // Base64 encoded image
    required: false
  }
}, { timestamps: true });

userSchema.pre('save', async function () {

  // Allow only one admin
  if (this.role === 'admin') {
    const existingAdmin = await this.constructor.findOne({ role: 'admin' });

    if (existingAdmin && existingAdmin._id.toString() !== this._id.toString()) {
      throw new Error('Only one admin is allowed');
    }
  }

  // Hash password
  if (!this.isModified('password')) return;

  const salt = await require('bcryptjs').genSalt(10);
  const hashedPassword = await require('bcryptjs').hash(this.password, salt);
  this.password = hashedPassword;
});
// Compare Password Method
userSchema.methods.comparePassword = async function (candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (err) {
    throw err;
  }
};

const User = mongoose.models.User || mongoose.model('User', userSchema);
module.exports = User;