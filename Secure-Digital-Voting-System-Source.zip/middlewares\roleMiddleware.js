const User = require("../models/user");
const ApiError = require("../utils/ApiError");
const catchAsync = require("../utils/catchAsync");

const isAdmin = catchAsync(async (req, res, next) => {
  if (!req.user || !req.user.id) {
    throw new ApiError(401, "Unauthorized access, please login");
  }

  const user = await User.findById(req.user.id);

  if (!user || user.role !== "admin") {
    throw new ApiError(403, "Forbidden, Admin privileges required");
  }

  // Pass user along to next middleware if needed
  req.userDetails = user;
  next();
});

module.exports = { isAdmin };
