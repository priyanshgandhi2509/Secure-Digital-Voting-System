const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Candidate = require('../models/candidate');

dotenv.config();

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        console.log("Testing validation for state candidate WITHOUT state...");
        const c1 = new Candidate({
            name: "Validation Test Candidate",
            party: "VTC",
            age: 30,
            electionType: "state"
        });

        try {
            await c1.validate();
            console.log("❌ ERROR: Validation succeeded but SHOULD HAVE FAILED!");
        } catch (err) {
            console.log("✅ SUCCESS: Validation correctly failed with error:");
            console.log(err.message);
        }

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
