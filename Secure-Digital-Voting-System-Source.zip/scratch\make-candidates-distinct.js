const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Candidate = require('../models/candidate');

dotenv.config();

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        // Update the 55-year-old candidate to Maharashtra
        const result1 = await Candidate.updateOne(
            { electionType: 'state', age: 55 },
            { $set: { state: 'Maharashtra' } }
        );
        console.log(`Updated 55-year-old candidate: ${result1.modifiedCount} document(s)`);

        // Update the 60-year-old candidate to Gujarat
        const result2 = await Candidate.updateOne(
            { electionType: 'state', age: 60 },
            { $set: { state: 'Gujarat' } }
        );
        console.log(`Updated 60-year-old candidate: ${result2.modifiedCount} document(s)`);

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
