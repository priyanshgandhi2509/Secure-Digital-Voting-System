const dns = require('dns');
dns.setDefaultResultOrder('ipv4first');

const path = require('path');
const mongoose = require('mongoose');

const standardUrl = "mongodb://priyanshgandhi69_db_user:LkgZAo9WOsGDuDJ9@ac-fdtn8hn-shard-00-00.n1e9nlp.mongodb.net:27017,ac-fdtn8hn-shard-00-01.n1e9nlp.mongodb.net:27017,ac-fdtn8hn-shard-00-02.n1e9nlp.mongodb.net:27017/vootingapp?authSource=admin&replicaSet=atlas-gepk6u-shard-0&ssl=true";

console.log("Connecting using standard URL...");

mongoose.connect(standardUrl)
  .then(() => {
    console.log("✅ Successfully connected to MongoDB via standard URL!");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Connection failed:", err);
    process.exit(1);
  });
