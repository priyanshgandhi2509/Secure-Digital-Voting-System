const dns = require('dns');
dns.setDefaultResultOrder('ipv4first');

const path = require('path');
const mongoose = require('mongoose');

// Configure Env
require('dotenv').config();

const mongoUrl = process.env.MONGO_URL || "mongodb://priyanshgandhi69_db_user:LkgZAo9WOsGDuDJ9@ac-fdtn8hn-shard-00-00.n1e9nlp.mongodb.net:27017,ac-fdtn8hn-shard-00-01.n1e9nlp.mongodb.net:27017,ac-fdtn8hn-shard-00-02.n1e9nlp.mongodb.net:27017/vooting-app?authSource=admin&replicaSet=atlas-gepk6u-shard-0&ssl=true";

// Import Models
const User = require('../models/user');
const Election = require('../models/election');
const Candidate = require('../models/candidate');
const OTP = require('../models/otp');

// Import Controllers
const userController = require('../controllers/userController');
const electionController = require('../controllers/electionController');
const candidateController = require('../controllers/candidateController');

// Helper to run wrapped controllers
const runController = async (controllerFn, req, res) => {
  return new Promise((resolve, reject) => {
    const next = (err) => {
      if (err) reject(err);
      else resolve();
    };

    // Override res.json/res.send to resolve promise on success
    const originalJson = res.json;
    res.json = function(data) {
      if (originalJson) originalJson.call(res, data);
      resolve(data);
    };

    const originalSend = res.send;
    res.send = function(data) {
      if (originalSend) originalSend.call(res, data);
      resolve(data);
    };

    controllerFn(req, res, next);
  });
};

function createMockReqRes(body = {}, params = {}, user = {}) {
  const req = {
    body,
    params,
    user,
    ip: '127.0.0.1',
    app: {
      get: () => null // Stub socket.io
    }
  };

  let resStatus = 200;
  let resData = null;

  const res = {
    status: function(code) {
      resStatus = code;
      return this;
    },
    json: function(data) {
      resData = data;
      return this;
    },
    header: function() { return this; },
    attachment: function() { return this; },
    send: function(data) {
      resData = data;
      return this;
    }
  };

  return { req, res, getStatus: () => resStatus };
}

async function runTests() {
  console.log("🚀 Starting verification tests...\n");

  // 1. Cleanup
  console.log("🧹 Cleaning up old test data...");
  await User.deleteMany({ aadharCardNumber: { $in: ["111111111111", "222222222222"] } });
  await Election.deleteMany({});
  await Candidate.deleteMany({ name: "Test Candidate" });
  console.log("✅ Cleanup complete.\n");

  // Setup sample face descriptors (128 dimensions)
  // Generate unique random descriptors to prevent matching existing records in the database
  const faceDescriptorA = Array.from({ length: 128 }, () => Math.random());
  // Make Face B highly distinct from Face A (Euclidean distance will be > 0.6)
  const faceDescriptorB = faceDescriptorA.map(val => val > 0.5 ? val - 0.45 : val + 0.45);

  const adminId = new mongoose.Types.ObjectId().toString();

  // 2. Test Signup Duplicate Face Check
  console.log("📝 Test: User A Signup (Face A)...");
  const { req: signupReqA, res: signupResA } = createMockReqRes({
    name: "User A",
    age: 25,
    state: "Gujarat",
    city: "Surat",
    address: "123 Surat St",
    email: "usera@example.com",
    aadharCardNumber: "111111111111",
    password: "password123",
    role: "voter",
    faceDescriptor: faceDescriptorA,
    photo: "data:image/jpeg;base64,mockA"
  });

  const signupResultA = await runController(userController.signup, signupReqA, signupResA);
  console.log("✅ User A registered successfully.");
  const userAId = signupResultA.data.user._id;

  console.log("\n📝 Test: Duplicate Face Signup (User B with Face A)...");
  const { req: signupReqB1, res: signupResB1 } = createMockReqRes({
    name: "User B",
    age: 30,
    state: "Gujarat",
    city: "Ahmedabad",
    address: "456 Ah St",
    email: "userb@example.com",
    aadharCardNumber: "222222222222",
    password: "password123",
    role: "voter",
    faceDescriptor: faceDescriptorA, // Same face as User A!
    photo: "data:image/jpeg;base64,mockA"
  });

  try {
    await runController(userController.signup, signupReqB1, signupResB1);
    console.error("❌ FAILED: Duplicate face registration was allowed!");
    process.exit(1);
  } catch (err) {
    console.log("✅ SUCCESS: Duplicate face registration was correctly blocked with error:", err.message);
  }

  console.log("\n📝 Test: User B Signup (Face B - Distinct)...");
  const { req: signupReqB2, res: signupResB2 } = createMockReqRes({
    name: "User B",
    age: 30,
    state: "Gujarat",
    city: "Ahmedabad",
    address: "456 Ah St",
    email: "userb@example.com",
    aadharCardNumber: "222222222222",
    password: "password123",
    role: "voter",
    faceDescriptor: faceDescriptorB, // Distinct face
    photo: "data:image/jpeg;base64,mockB"
  });

  const signupResultB = await runController(userController.signup, signupReqB2, signupResB2);
  console.log("✅ User B registered successfully with unique face.");
  const userBId = signupResultB.data.user._id;

  // 3. Test Sequential Elections Check
  console.log("\n🗳️ Test: Create Active Election 1...");
  const { req: createEleReq1, res: createEleRes1 } = createMockReqRes({
    name: "General Election 2026",
    status: "active",
    electionType: "national"
  }, {}, { id: adminId });

  await runController(electionController.createElection, createEleReq1, createEleRes1);
  console.log("✅ Active Election 1 created successfully.");

  console.log("\n🗳️ Test: Try to Create Active Election 2 (Should Fail)...");
  const { req: createEleReq2, res: createEleRes2 } = createMockReqRes({
    name: "State Election 2026",
    status: "active",
    electionType: "state",
    activeState: "Gujarat"
  }, {}, { id: adminId });

  try {
    await runController(electionController.createElection, createEleReq2, createEleRes2);
    console.error("❌ FAILED: Parallel active election creation was allowed!");
    process.exit(1);
  } catch (err) {
    console.log("✅ SUCCESS: Parallel active election creation blocked with error:", err.message);
  }

  console.log("\n🗳️ Test: Create Upcoming Election 2 (Should Succeed)...");
  const { req: createEleReq3, res: createEleRes3 } = createMockReqRes({
    name: "State Election 2026",
    status: "upcoming",
    electionType: "state",
    activeState: "Gujarat"
  }, {}, { id: adminId });

  await runController(electionController.createElection, createEleReq3, createEleRes3);
  console.log("✅ Upcoming Election 2 created successfully.");

  console.log("\n🗳️ Test: Try to Activate Upcoming Election 2 while Election 1 is Active (Should Fail)...");
  const { req: updateEleReq1, res: updateEleRes1 } = createMockReqRes({
    status: "active",
    electionType: "state",
    activeState: "Gujarat"
  }, {}, { id: adminId });

  try {
    await runController(electionController.updateElection, updateEleReq1, updateEleRes1);
    console.error("❌ FAILED: Activating election while another is active was allowed!");
    process.exit(1);
  } catch (err) {
    console.log("✅ SUCCESS: Activating election while another is active blocked with error:", err.message);
  }

  console.log("\n🗳️ Test: Complete Election 1 (Update status)...");
  // Since updateElection finds the latest election document, to update Election 1 we can first make it completed.
  // Wait, let's complete the active election by doing updateElection status: "completed" on Election 1.
  // But wait, the latest election is Election 2 (Upcoming). If we call updateElection, it will update the latest election (Election 2).
  // If we want to complete Election 1, let's directly update it in the database to status: "completed".
  await Election.updateOne({ name: "General Election 2026" }, { status: "completed" });
  console.log("✅ Election 1 marked as completed in DB.");

  console.log("\n🗳️ Test: Try to Activate Election 2 now that Election 1 is complete (Should Succeed)...");
  const { req: updateEleReq2, res: updateEleRes2 } = createMockReqRes({
    status: "active",
    electionType: "state",
    activeState: "Gujarat"
  }, {}, { id: adminId });

  await runController(electionController.updateElection, updateEleReq2, updateEleRes2);
  console.log("✅ Election 2 activated successfully after completion of the previous election.");

  // Create a candidate for voting test
  const candidate = await Candidate.create({
    name: "Test Candidate",
    party: "TAP",
    age: 45,
    electionType: "state",
    state: "Gujarat"
  });

  // 4. Test Strict Face Matching at Vote Time
  // Generate OTP first
  const { req: otpReq, res: otpRes } = createMockReqRes({}, {}, { id: userAId });
  await runController(userController.requestOTP, otpReq, otpRes);
  const otpRecord = await OTP.findOne({ userId: userAId });
  const otpCode = otpRecord.otp;
  console.log(`\n🔑 Simulation OTP for User A: ${otpCode}`);

  console.log("\n🗳️ Test: User A attempts to vote using User B's Face Descriptor (Should Fail)...");
  const { req: voteReq1, res: voteRes1 } = createMockReqRes({
    otp: otpCode,
    liveFaceDescriptor: faceDescriptorB // Face descriptor belonging to User B
  }, { candidateID: candidate._id }, { id: userAId });

  try {
    await runController(candidateController.voteForCandidate, voteReq1, voteRes1);
    console.error("❌ FAILED: User A was allowed to vote with User B's face!");
    process.exit(1);
  } catch (err) {
    console.log("✅ SUCCESS: Voting blocked when face matched another registered user (User B) with error:", err.message);
  }

  console.log("\n🗳️ Test: User A attempts to vote with their own Face Descriptor (Should Succeed)...");
  const { req: voteReq2, res: voteRes2 } = createMockReqRes({
    otp: otpCode,
    liveFaceDescriptor: faceDescriptorA // Correct face descriptor belonging to User A
  }, { candidateID: candidate._id }, { id: userAId });

  await runController(candidateController.voteForCandidate, voteReq2, voteRes2);
  console.log("✅ SUCCESS: User A voted successfully with their own registered face descriptor!");

  console.log("\n🌟 All verification checks passed perfectly!");
  process.exit(0);
}

mongoose.connect(mongoUrl)
  .then(() => {
    console.log("🔌 Connected to MongoDB");
    runTests();
  })
  .catch(err => {
    console.error("MongoDB connection failed:", err);
    process.exit(1);
  });
