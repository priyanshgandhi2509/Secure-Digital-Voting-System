const mongoose = require('mongoose');
const crypto = require('crypto');

const voteLedgerSchema = new mongoose.Schema({
  voterId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true // One voter, one entry in the ledger
  },
  candidateId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Candidate',
    required: true
  },
  previousHash: {
    type: String,
    required: true
  },
  hash: {
    type: String,
    required: true,
    unique: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
  signature: {
    type: String,
    required: true
  }
}, { timestamps: true });

// Function to calculate hash for the block
voteLedgerSchema.statics.calculateHash = function(voterId, candidateId, previousHash, timestamp) {
  return crypto.createHash('sha256')
    .update(voterId.toString() + candidateId.toString() + previousHash + timestamp.toString())
    .digest('hex');
};

const VoteLedger = mongoose.models.VoteLedger || mongoose.model('VoteLedger', voteLedgerSchema);

module.exports = VoteLedger;
