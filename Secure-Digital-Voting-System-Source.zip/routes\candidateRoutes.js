const express = require('express');
const router = express.Router();
const candidateController = require('../controllers/candidateController');
const { jwtAuthMiddleware } = require('../middlewares/authMiddleware');
const { isAdmin } = require('../middlewares/roleMiddleware');

// Public but JWT protected voting/results
router.post('/vote/:candidateID', jwtAuthMiddleware, candidateController.voteForCandidate);
router.get('/vote/count', candidateController.getVoteCount);
router.get('/results/stats', candidateController.getResultsStats);
router.get('/results', candidateController.getResults);
router.get('/list', jwtAuthMiddleware, candidateController.getAllCandidates);
router.get('/ai-prediction', candidateController.getAIPrediction);
router.post('/ai-chat', candidateController.aiChat);
router.get('/verify-ledger', candidateController.verifyLedger);

// Admin only routes
router.use(jwtAuthMiddleware, isAdmin);
router.get('/export/csv', candidateController.exportResultsCSV);
router.post('/', candidateController.addCandidate);
router.put('/:candidateID', candidateController.updateCandidate);
router.delete('/:candidateID', candidateController.deleteCandidate);

module.exports = router;