const User = require('../models/user');
const { generateToken } = require('../middlewares/authMiddleware');
const ApiError = require('../utils/ApiError');
const ApiResponse = require('../utils/ApiResponse');
const catchAsync = require('../utils/catchAsync');
const { validationResult } = require('express-validator');
const OTP = require('../models/otp');

const sendEmail = require('../utils/emailService');

// Mock function for Nodemailer OTP email / SMS simulation
const simulateExternalNotification = async (email, mobile, message) => {
  console.log(`\n===================`);
  console.log(`[EXTERNAL_SMS] Sent to ${mobile}: ${message}`);
  
  if (email) {
    console.log(`[EXTERNAL_EMAIL] Sending real email to ${email}...`);
    await sendEmail(
      email, 
      "Vooting - Verification Code", 
      message, 
      `<div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd;">
        <h2 style="color: #6a11cb;">Secure Voting Verification</h2>
        <p>${message}</p>
        <hr/>
        <p style="font-size: 0.8rem; color: #777;">If you did not request this code, please ignore this email.</p>
       </div>`
    );
  }
  console.log(`===================\n`);
};

const signup = catchAsync(async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    throw new ApiError(400, "Validation failed", errors.array());
  }

  const { faceDescriptor } = req.body;

  // Check if faceDescriptor already matches any existing user's face
  if (faceDescriptor && faceDescriptor.length > 0) {
    const existingUsers = await User.find({ faceDescriptor: { $exists: true, $ne: [] } });
    for (const otherUser of existingUsers) {
      if (otherUser.faceDescriptor && otherUser.faceDescriptor.length === faceDescriptor.length) {
        let otherSum = 0;
        for (let i = 0; i < otherUser.faceDescriptor.length; i++) {
          const diff = otherUser.faceDescriptor[i] - faceDescriptor[i];
          otherSum += diff * diff;
        }
        const otherDistance = Math.sqrt(otherSum);
        if (otherDistance <= 0.6) {
          throw new ApiError(400, `Registration failed. This face is already registered under a different Aadhar Card (${otherUser.aadharCardNumber.substring(0, 8)}XXXX). Duplicate face registrations are strictly prohibited.`);
        }
      }
    }
  }

  const newUser = new User(req.body);
  const savedUser = await newUser.save();

  const payload = { id: savedUser._id };
  const token = generateToken(payload);

  // Send an OTP Notification to verify them (simulating the Twilio/Nodemailer behavior)
  simulateExternalNotification(savedUser.email, savedUser.mobile, "Welcome to Voting App! Your Account is secure.");

  res.status(201).json(new ApiResponse(201, { user: savedUser, token }, "User created and Verified successfully"));
});

const login = catchAsync(async (req, res) => {
  let { aadharCardNumber, password } = req.body;
  if (aadharCardNumber) aadharCardNumber = aadharCardNumber.toString().trim();
  if (password) password = password.trim();

  if (!aadharCardNumber || !password) {
    throw new ApiError(400, "Aadhar card number and password are required");
  }

  const user = await User.findOne({ aadharCardNumber });
  if (!user || !(await user.comparePassword(password))) {
    throw new ApiError(401, "Invalid aadhar card number or password");
  }

  const payload = { id: user.id };
  const token = generateToken(payload);

  res.status(200).json(new ApiResponse(200, { token, user }, "Logged in successfully"));
});

const updatePassword = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    throw new ApiError(400, "Current and new passwords are required");
  }

  const user = await User.findById(userId);
  if (!user) {
    throw new ApiError(404, "User not found");
  }

  const isMatch = await user.comparePassword(currentPassword);
  if (!isMatch) {
    throw new ApiError(401, "Current password incorrect");
  }

  user.password = newPassword;
  await user.save();

  res.status(200).json(new ApiResponse(200, null, "Password updated successfully"));
});

const requestOTP = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const user = await User.findById(userId);
  if (!user) throw new ApiError(404, "User not found");

  // Verify Election constraints early to prevent unnecessary OTP generation
  const Election = require('../models/election');
  const election = await Election.findOne().sort({ createdAt: -1 });

  if (!election || election.status !== 'active') {
    throw new ApiError(403, "Voting is currently closed or not yet active");
  }

  if (election.electionType === 'state') {
     if (election.activeState && election.activeState.toLowerCase() !== user.state.toLowerCase()) {
        throw new ApiError(403, `You are not applicable for voting. Currently, only the ${election.activeState} state election is active.`);
     }
  }

  const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

  await OTP.deleteMany({ userId }); // Clear old ones
  await OTP.create({ userId, otp: otpCode });

  simulateExternalNotification(user.email, user.mobile, `Your Voting Verification Code is: ${otpCode}. It expires in 10 minutes.`);

  res.status(200).json(new ApiResponse(200, { devOtp: otpCode }, "OTP sent successfully"));
});

module.exports = {
  signup,
  login,
  updatePassword,
  requestOTP
};
