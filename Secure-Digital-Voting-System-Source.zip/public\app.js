const API_BASE = '/api/v1';
let userToken = localStorage.getItem('vootingToken');
let userRole = localStorage.getItem('vootingRole');
let userName = localStorage.getItem('vootingName');
let isVoted = localStorage.getItem('vootingIsVoted') === 'true';

const DOM = {
    navLinks: document.getElementById('nav-links'),
    navLogin: document.getElementById('nav-login'),
    navSignup: document.getElementById('nav-signup'),
    authSection: document.getElementById('auth-section'),
    dashboardSection: document.getElementById('dashboard-section'),
    adminSection: document.getElementById('admin-section'),
    loginContainer: document.getElementById('login-container'),
    signupContainer: document.getElementById('signup-container'),
    toSignup: document.getElementById('to-signup'),
    toLogin: document.getElementById('to-login'),
    loginForm: document.getElementById('login-form'),
    signupForm: document.getElementById('signup-form'),
    notification: document.getElementById('notification'),
    userGreeting: document.getElementById('user-greeting'),
    electionStatus: document.getElementById('election-status'),
    indicator: document.querySelector('.indicator'),
    logoutBtn: document.getElementById('logout-btn'),
    adminLogoutBtn: document.getElementById('admin-logout-btn'),
    candidatesList: document.getElementById('candidates-list'),
    resultsList: document.getElementById('results-list'),
    tabs: document.querySelectorAll('.tab'),
    refreshResultsBtn: document.getElementById('refresh-results-btn'),
    addCandidateForm: document.getElementById('add-candidate-form'),
    toggleElectionBtn: document.getElementById('toggle-election-btn'),
    exportCsvBtn: document.getElementById('export-csv-btn'),
    adminCandidatesList: document.getElementById('admin-candidates-list'),
    editModal: document.getElementById('edit-modal'),
    closeModal: document.getElementById('close-modal'),
    editCandidateForm: document.getElementById('edit-candidate-form'),
    otpModal: document.getElementById('otp-modal'),
    otpInput: document.getElementById('otp-input'),
    confirmOtpBtn: document.getElementById('confirm-otp-btn'),
    cancelOtpBtn: document.getElementById('cancel-otp-btn'),
    verificationSegment: document.getElementById('verification-segment'),
    dashboardOtpInput: document.getElementById('dashboard-otp-input'),
    dashboardConfirmBtn: document.getElementById('dashboard-confirm-btn'),
    dashboardCancelBtn: document.getElementById('dashboard-cancel-btn'),
    votedForName: document.getElementById('voted-for-name'),
    candidatesArea: document.querySelector('.candidates-area'),
    signupState: document.getElementById('signup-state'),
    resultsSearch: document.getElementById('results-search'),
    aiPredictBtn: document.getElementById('ai-predict-btn'),
    aiPredictionContent: document.getElementById('ai-prediction-content')
};

// --- Utilities ---
const showNotification = (msg, type = 'success') => {
    DOM.notification.textContent = msg;
    DOM.notification.className = `toast ${type}`;
    setTimeout(() => { DOM.notification.classList.add('hidden'); }, 3000);
};

const switchAuth = (to) => {
    if (signupStream) signupStream.getTracks().forEach(track => track.stop());
    if (to === 'signup') {
        DOM.loginContainer.classList.add('hidden');
        DOM.signupContainer.classList.remove('hidden');
        DOM.navLogin.classList.remove('active');
        DOM.navSignup.classList.add('active');
    } else {
        DOM.signupContainer.classList.add('hidden');
        DOM.loginContainer.classList.remove('hidden');
        DOM.navSignup.classList.remove('active');
        DOM.navLogin.classList.add('active');
    }
};

// --- Face API Logic ---
let modelsLoaded = false;
let signupFaceDescriptor = null;
let voteFaceDescriptor = null;
let signupStream = null;
let voteStream = null;

async function loadFaceModels() {
    if (modelsLoaded) return;
    try {
        // Use tinyFaceDetector for faster, more reliable web performance
        const modelUrl = '/models';
        await faceapi.nets.tinyFaceDetector.loadFromUri(modelUrl);
        await faceapi.nets.faceLandmark68Net.loadFromUri(modelUrl);
        await faceapi.nets.faceRecognitionNet.loadFromUri(modelUrl);
        modelsLoaded = true;
        console.log("Face models loaded successfully");
    } catch (err) {
        console.error("Error loading face models", err);
        alert("Failed to load AI face models. Please check your internet connection.");
    }
}

// Signup Camera
document.getElementById('start-signup-cam').addEventListener('click', async () => {
    document.getElementById('signup-photo-status').innerText = "Loading AI face models (can take a few seconds)...";
    await loadFaceModels();
    const video = document.getElementById('signup-video');
    try {
        signupStream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = signupStream;
        video.style.display = 'block';
        document.getElementById('start-signup-cam').style.display = 'none';
        document.getElementById('capture-signup-photo').style.display = 'block';
        document.getElementById('signup-photo-status').innerText = "Position your face and click Capture Face.";
    } catch (e) {
        alert("Camera access denied or unavailable.");
    }
});

let signupBase64Photo = null;
let voteBase64Photo = null;

document.getElementById('capture-signup-photo').addEventListener('click', async () => {
    const video = document.getElementById('signup-video');
    const statusEl = document.getElementById('signup-photo-status');
    statusEl.innerText = "Detecting face...";
    statusEl.style.color = "#ffeb3b";
    
    try {
        // Always capture a base64 photo first
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        signupBase64Photo = canvas.toDataURL('image/jpeg', 0.8);

        // Pass the static canvas to faceapi instead of the live video element. This prevents "media dimensions" errors.
        const detection = await faceapi.detectSingleFace(canvas, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();

        if (detection) {
            signupFaceDescriptor = Array.from(detection.descriptor);
            statusEl.innerText = "Face captured successfully! ✅";
            statusEl.style.color = "#00ff88";
            
            // Show captured photo preview
            video.style.display = 'none';
            document.getElementById('signup-canvas').style.display = 'block';
            const displayCtx = document.getElementById('signup-canvas').getContext('2d');
            document.getElementById('signup-canvas').width = canvas.width;
            document.getElementById('signup-canvas').height = canvas.height;
            displayCtx.drawImage(canvas, 0, 0, canvas.width, canvas.height);
            
            if (signupStream) {
                signupStream.getTracks().forEach(track => track.stop());
                document.getElementById('capture-signup-photo').style.display = 'none';
            }
        } else {
            statusEl.innerText = "No face detected in photo. Please ensure good lighting and try again.";
            statusEl.style.color = "#ff4444";
        }
    } catch (err) {
        console.error(err);
        statusEl.innerText = "Error: " + (err.message || err.toString());
        statusEl.style.color = "#ff4444";
    }
});

const route = () => {
    if (userToken) {
        DOM.authSection.classList.add('hidden');
        DOM.navLinks.classList.add('hidden');

        if (userRole === 'admin') {
            DOM.adminSection.classList.remove('hidden');
            DOM.dashboardSection.classList.add('hidden');
            fetchAdminCandidates();
        } else {
            DOM.dashboardSection.classList.remove('hidden');
            DOM.adminSection.classList.add('hidden');
            DOM.userGreeting.textContent = `Welcome, ${userName || 'Voter'}`;
            fetchElectionStatus();
            fetchCandidates('national');
            fetchResults('national');
        }
    } else {
        DOM.authSection.classList.remove('hidden');
        DOM.dashboardSection.classList.add('hidden');
        DOM.adminSection.classList.add('hidden');
        DOM.navLinks.classList.remove('hidden');
    }
};

const logout = () => {
    localStorage.clear();
    userToken = null;
    userRole = null;
    userName = null;
    isVoted = false;
    route();
    showNotification('Logged out successfully');
};

// --- API Calls ---

const apiFetch = async (endpoint, options = {}) => {
    const headers = { 'Content-Type': 'application/json' };
    if (userToken) headers['Authorization'] = `Bearer ${userToken}`;
    const res = await fetch(`${API_BASE}${endpoint}`, { cache: 'no-store', ...options, headers });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Something went wrong');
    return data;
};

const handleLogin = async (e) => {
    e.preventDefault();
    const aadharCardNumber = document.getElementById('login-aadhar').value;
    const password = document.getElementById('login-password').value;

    try {
        const res = await apiFetch('/user/login', {
            method: 'POST',
            body: JSON.stringify({ aadharCardNumber, password })
        });

        userToken = res.data.token;
        userRole = res.data.user?.role || 'voter';
        userName = res.data.user?.name || '';
        isVoted = res.data.user?.isVoted || false;

        // Save the state they registered in so we can locally verify boundaries instantly
        const userState = res.data.user?.state || '';

        localStorage.setItem('vootingToken', userToken);
        localStorage.setItem('vootingRole', userRole);
        localStorage.setItem('vootingName', userName);
        localStorage.setItem('vootingIsVoted', isVoted);
        localStorage.setItem('vootingState', userState);

        DOM.loginForm.reset();
        showNotification('Login Successful');
        route();
    } catch (err) {
        showNotification(err.message, 'error');
    }
};

// --- Location Logic ---
const initLocationSelectors = () => {
    if (!DOM.signupState || !window.indiaLocations) return;

    const states = Object.keys(window.indiaLocations).sort();
    DOM.signupState.innerHTML = '<option value="">Select State</option>' +
        states.map(s => `<option value="${s}">${s}</option>`).join('');
};
initLocationSelectors();

const initAdminLocationSelectors = () => {
    const candState = document.getElementById('cand-state');
    const editCandState = document.getElementById('edit-cand-state');
    
    if (!candState || !editCandState || !window.indiaLocations) return;

    const states = Object.keys(window.indiaLocations).sort();
    const stateOptions = '<option value="">Select State</option>' +
        states.map(s => `<option value="${s}">${s}</option>`).join('');

    candState.innerHTML = stateOptions;
    editCandState.innerHTML = stateOptions;

    // Type listeners
    const candType = document.getElementById('cand-type');
    const candLocRow = document.getElementById('cand-loc-row');
    const candStateGroup = document.getElementById('cand-state-group');

    candType.addEventListener('change', (e) => {
        const val = e.target.value;
        if (val === 'national') {
            candLocRow.classList.add('hidden');
            candState.required = false;
        } else if (val === 'state') {
            candLocRow.classList.remove('hidden');
            candStateGroup.classList.remove('hidden');
            candState.required = true;
        }
    });

    const editCandType = document.getElementById('edit-cand-type');
    const editCandLocRow = document.getElementById('edit-cand-loc-row');
    const editCandStateGroup = document.getElementById('edit-cand-state-group');

    editCandType.addEventListener('change', (e) => {
        const val = e.target.value;
        if (val === 'national') {
            editCandLocRow.classList.add('hidden');
            editCandState.required = false;
        } else if (val === 'state') {
            editCandLocRow.classList.remove('hidden');
            editCandStateGroup.classList.remove('hidden');
            editCandState.required = true;
        }
    });
};
initAdminLocationSelectors();

const resetSignupFaceCapture = () => {
    signupFaceDescriptor = null;
    signupBase64Photo = null;
    if (signupStream) {
        signupStream.getTracks().forEach(track => track.stop());
        signupStream = null;
    }
    document.getElementById('signup-video').style.display = 'none';
    document.getElementById('signup-canvas').style.display = 'none';
    document.getElementById('start-signup-cam').style.display = 'block';
    document.getElementById('capture-signup-photo').style.display = 'none';
    const statusEl = document.getElementById('signup-photo-status');
    statusEl.innerText = "Please restart camera to capture a different face.";
    statusEl.style.color = "#ffeb3b";
};

const handleSignup = async (e) => {
    e.preventDefault();
    const payload = {
        name: document.getElementById('signup-name').value,
        age: parseInt(document.getElementById('signup-age').value),
        state: document.getElementById('signup-state').value,
        address: document.getElementById('signup-address').value,
        aadharCardNumber: document.getElementById('signup-aadhar').value,
        password: document.getElementById('signup-password').value,
        role: document.getElementById('signup-role').value,
        faceDescriptor: signupFaceDescriptor,
        photo: signupBase64Photo
    };

    if (!signupFaceDescriptor || !signupBase64Photo) {
        showNotification('Face capture is required to register securely', 'error');
        return;
    }

    try {
        await apiFetch('/user/signup', {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        DOM.signupForm.reset();
        showNotification('Registration successful! Please login to continue.');
        switchAuth('login'); // Redirect to login page
    } catch (err) {
        showNotification(err.message, 'error');
        resetSignupFaceCapture(); // Reset face capture so user can capture a different photo
    }
};

const fetchElectionStatus = async () => {
    try {
        const res = await apiFetch('/election/status');
        const status = res.data?.status || 'inactive';

        window.activeElectionType = res.data?.electionType || 'national';
        window.activeElectionState = res.data?.activeState || null;
        window.electionIsActive = status === 'active';

        let statusText = `Status: ${status.toUpperCase()}`;
        if (status === 'active' && res.data.electionType) {
            statusText += ` (${res.data.electionType.toUpperCase()}`;
            if (res.data.electionType === 'state' && res.data.activeState) {
                statusText += ` - ${res.data.activeState}`;
            }
            statusText += `)`;
        }
        DOM.electionStatus.textContent = statusText;
        if (status === 'active') {
            DOM.indicator.classList.remove('inactive');
        } else {
            DOM.indicator.classList.add('inactive');
        }
    } catch (err) {
        DOM.electionStatus.textContent = `Status: ERROR`;
        DOM.indicator.classList.add('inactive');
    }
};

const fetchCandidates = async (typeFilter = 'national') => {
    try {
        DOM.candidatesList.innerHTML = '<p>Loading candidates...</p>';
        const res = await apiFetch('/candidate/list');
        const candidates = res.data.filter(c => c.electionType === typeFilter);

        if (candidates.length === 0) {
            DOM.candidatesList.innerHTML = '<p>No candidates found for this level</p>';
            return;
        }

        DOM.candidatesList.innerHTML = candidates.map(c => {
            let voteBtnHtml = `<button class="btn-vote" data-id="${c._id}" ${isVoted ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''}>
                ${isVoted ? 'Voted' : 'Vote Now'}
            </button>`;

            // Check geographical & level restrictions for frontend graying-out
            const localUserLoc = localStorage.getItem('vootingState') || '';
            const isActiveStateEl = window.activeElectionType === 'state';

            if (!window.electionIsActive) {
                voteBtnHtml = `<button class="btn-vote" disabled style="opacity:0.5; cursor:not-allowed;">Election Closed</button>`;
            } else if (isActiveStateEl) {
                if (c.electionType !== 'state') {
                    voteBtnHtml = `<button class="btn-vote" disabled style="opacity:0.5; cursor:not-allowed;" title="State election currently active">Not Applicable</button>`;
                } else if (window.activeElectionState && window.activeElectionState.toLowerCase() !== localUserLoc.toLowerCase()) {
                    voteBtnHtml = `<button class="btn-vote" disabled style="opacity:0.5; cursor:not-allowed;" title="Only ${window.activeElectionState} election is active">Not Applicable</button>`;
                }
            } else if (window.activeElectionType === 'national' && c.electionType !== 'national') {
                voteBtnHtml = `<button class="btn-vote" disabled style="opacity:0.5; cursor:not-allowed;" title="National election currently active">Not Applicable</button>`;
            }

            return `
                <div class="candidate-card glass-card">
                    <h3>${c.name}</h3>
                    <p>Party: <strong>${c.party}</strong></p>
                    <p style="font-size: 0.85rem; opacity: 0.8; margin-bottom: 10px;">
                        Level: ${c.electionType.charAt(0).toUpperCase() + c.electionType.slice(1)} ${c.state ? `(${c.state}${c.city ? `, ${c.city}` : ''})` : ''}
                    </p>
                    <div class="row">
                        ${voteBtnHtml}
                    </div>
                </div>
            `;
        }).join('');

        // Attach event listeners safely to comply with Helmet CSP
        document.querySelectorAll('.btn-vote').forEach(btn => {
            btn.addEventListener('click', (e) => {
                if (!isVoted) {
                    window.castVote(e.currentTarget.dataset.id);
                }
            });
        });
    } catch (err) {
        DOM.candidatesList.innerHTML = `<p style="color:red">${err.message}</p>`;
    }
};

const fetchResults = async (typeFilter = 'national', stateFilter = null) => {
    try {
        DOM.resultsList.innerHTML = `<p>Loading live results ${stateFilter ? 'for ' + stateFilter : ''}...</p>`;
        let url = `/candidate/results?type=${typeFilter}`;
        if (stateFilter) url += `&state=${encodeURIComponent(stateFilter)}`;

        const res = await apiFetch(url);
        let groupedResults = res.data;

        if (groupedResults.length === 0) {
            DOM.resultsList.innerHTML = `<p>No votes casted yet ${stateFilter ? 'in ' + stateFilter : 'for ' + typeFilter + ' election'}.</p>`;
            return;
        }

        const renderResults = (data, query = '') => {
            if (!query) {
                DOM.resultsList.innerHTML = '<p class="search-hint">Enter a state or city name to view live results.</p>';
                return;
            }
            if (data.length === 0) {
                DOM.resultsList.innerHTML = '<p>No results found for "' + query + '".</p>';
                return;
            }
            // Consolidate data to prevent duplicate location cards displaying differing case (e.g. 'Gujarat' vs 'gujarat')
            const consolidated = Object.values(data.reduce((acc, group) => {
                const rawLoc = group.location || group.city || group.state || 'Area';
                let parentName = (group.parentState || (group.city ? group.state : '') || '');
                if (!parentName && group.city && window.indiaLocations) {
                    for (const [state, cities] of Object.entries(window.indiaLocations)) {
                        if (cities.map(c => c.toLowerCase()).includes(group.city.toLowerCase())) {
                            parentName = state;
                            break;
                        }
                    }
                }
                const key = (rawLoc + '_' + parentName).toLowerCase();
                const total = group.totalVotes !== undefined ? group.totalVotes : group.results.reduce((a, r) => a + r.votes, 0);

                if (!acc[key]) {
                    // Capitalize the first letter of the location for a cleaner UI
                    const fmtLoc = rawLoc.charAt(0).toUpperCase() + rawLoc.slice(1).toLowerCase();
                    acc[key] = {
                        locName: fmtLoc,
                        parentName,
                        totalVotes: 0,
                        results: {}
                    };
                }

                acc[key].totalVotes += total;
                group.results.forEach(r => {
                    const rKey = r.candidateName + '_' + r.party;
                    if (!acc[key].results[rKey]) {
                        acc[key].results[rKey] = { ...r };
                    } else {
                        acc[key].results[rKey].votes += r.votes;
                    }
                });
                return acc;
            }, {}));

            DOM.resultsList.innerHTML = consolidated.map(group => {
                const resultsArr = Object.values(group.results).sort((a, b) => b.votes - a.votes);
                const maxVotesInGroup = Math.max(...resultsArr.map(r => r.votes), 1);

                return `
                    <div class="result-group fade-in">
                        <h4 class="group-title">
                            <span>${group.locName} ${group.parentName ? `<small style="font-size:0.75rem; opacity:0.6; display:block; margin-top:2px;">${group.parentName}</small>` : ''}</span>
                            <span class="total-badge">${group.totalVotes} Votes</span>
                        </h4>
                        <div class="group-items">
                            ${resultsArr.map(r => {
                    const width = (r.votes / maxVotesInGroup) * 100;
                    return `
                                <div class="result-item small">
                                    <div class="result-info">
                                        <span class="party-name">${r.party}</span>
                                        <span class="vote-count">${r.votes}</span>
                                    </div>
                                    <div class="progress-bar mini">
                                        <div class="progress-fill" style="width: ${width}%"></div>
                                    </div>
                                </div>
                                `
                }).join('')}
                        </div>
                    </div>
                `;
            }).join('');
        };

        // Initial state: Show nothing except hint
        const currentQuery = DOM.resultsSearch.value.toLowerCase().trim();
        if (currentQuery) {
            const filtered = groupedResults.filter(g => {
                const loc = (g.location || '').toLowerCase();
                const parent = (g.parentState || '').toLowerCase();
                return loc.includes(currentQuery) || parent.includes(currentQuery);
            });
            renderResults(filtered, currentQuery);
        } else {
            renderResults([], '');
        }

        // Handle search
        DOM.resultsSearch.oninput = async (e) => {
            const query = e.target.value.toLowerCase().trim();
            if (!query) {
                renderResults([], '');
                return;
            }

            const getFiltered = (data) => data.filter(g => {
                const locName = (g.location || g.city || g.state || '').toLowerCase();
                let parentName = (g.parentState || (g.city ? g.state : '') || '').toLowerCase();
                if (!parentName && g.city && window.indiaLocations) {
                    for (const [state, cities] of Object.entries(window.indiaLocations)) {
                        if (cities.map(c => c.toLowerCase()).includes(g.city.toLowerCase())) {
                            parentName = state.toLowerCase();
                            break;
                        }
                    }
                }
                return locName.startsWith(query) || parentName.startsWith(query);
            });

            let filtered = getFiltered(groupedResults);

            // If no match in current tab, try searching the other level automatically
            if (filtered.length === 0) {
                try {
                    const activeType = document.querySelector('.tab.active')?.dataset.type || 'national';
                    const otherType = activeType === 'national' ? 'state' : 'national';
                    const otherDataRes = await apiFetch(`/candidate/results?type=${otherType}`);
                    filtered = getFiltered(otherDataRes.data);
                } catch (err) {
                    console.error("Cross-tab search failed", err);
                }
            }


            renderResults(filtered, query);
            updateAnalytics(filtered);
        };

        const updateAnalytics = (data) => {
            const turnoutEl = document.getElementById('turnout-stat');
            const statesEl = document.getElementById('active-states-stat');
            if (!turnoutEl || !statesEl) return;

            const totalVotes = data.reduce((acc, curr) => acc + curr.totalVotes, 0);
            const totalStates = data.filter(d => !d.parentState).length;

            // Simulating a percentage based on arbitrary 1000 potential users per area
            const turnout = totalVotes > 0 ? ((totalVotes / (data.length * 100)) * 100).toFixed(1) : "0.0";

            turnoutEl.textContent = `${turnout}%`;
            statesEl.textContent = totalStates;
        };

        document.getElementById('audit-ledger-btn').onclick = async () => {
            const log = document.getElementById('audit-log');
            log.style.display = 'block';
            log.textContent = "⚙️ Calculating Cryptographic Hash...";

            try {
                const res = await apiFetch('/candidate/verify-ledger');
                const { isValid, totalBlocks } = res.data;
                log.innerHTML = `
                    <span style="color:${isValid ? '#00ff88' : '#ff4444'}">${isValid ? '✅ LEDGER VERIFIED (IMMUTABLE)' : '⚠️ TAMPERING DETECTED'}</span><br>
                    <span style="color:var(--secondary)">AUDIT RESULT:</span> ${isValid ? 'Success' : 'Failed'}<br>
                    <span style="color:var(--secondary)">TOTAL BLOCKS CHECKED:</span> ${totalBlocks}<br>
                    <span style="color:var(--secondary)">SYSTEM STATUS:</span> Online & Secure
                `;
            } catch (err) {
                log.textContent = "❌ Audit Failed: Restricted access. Admins only.";
            }
        };

    } catch (err) {
        DOM.resultsList.innerHTML = `<p style="color:red">${err.message}</p>`;
    }
};

let pendingVoteCandidateId = null;

window.castVote = async (candidateId) => {
    try {
        // 1. Prepare Inline Verification Section
        pendingVoteCandidateId = candidateId;

        // Get candidate name for display
        const card = document.querySelector(`.btn-vote[data-id="${candidateId}"]`).closest('.candidate-card');
        const candidateName = card.querySelector('h3').innerText;
        DOM.votedForName.innerText = candidateName;

        DOM.dashboardOtpInput.value = '';
        DOM.candidatesArea.classList.add('hidden');
        DOM.verificationSegment.classList.remove('hidden');

        // Reset Vote Camera State
        voteMode = 'start';
        document.getElementById('start-vote-cam').style.display = 'block';
        document.getElementById('start-vote-cam').innerText = "Start Camera for Verification";
        document.getElementById('vote-photo-status').innerText = "Please take a live photo to match your registration face.";
        document.getElementById('vote-photo-status').style.color = "#ffeb3b";
        DOM.dashboardConfirmBtn.disabled = true;
        voteFaceDescriptor = null;

    } catch (err) {
        showNotification(err.message, 'error');
    }
};

DOM.dashboardConfirmBtn.addEventListener('click', async () => {
    const otp = DOM.dashboardOtpInput.value.trim();
    if (otp.length !== 6) {
        showNotification("Please enter a valid 6-digit code", "error");
        return;
    }

    try {
        DOM.dashboardConfirmBtn.innerText = 'Verifying...';
        DOM.dashboardConfirmBtn.disabled = true;

        await apiFetch(`/candidate/vote/${pendingVoteCandidateId}`, {
            method: 'POST',
            body: JSON.stringify({ otp, liveFaceDescriptor: voteFaceDescriptor })
        });

        showNotification("Vote cast and verified cryptographically!");
        DOM.verificationSegment.classList.add('hidden');
        DOM.candidatesArea.classList.remove('hidden');

        isVoted = true;
        localStorage.setItem('vootingIsVoted', 'true');
        const activeType = document.querySelector('.tab.active')?.dataset.type || 'national';
        fetchCandidates(activeType);
        fetchResults(activeType);
    } catch (err) {
        showNotification(err.message, 'error');
    } finally {
        DOM.dashboardConfirmBtn.innerText = 'Verify & Confirm';
        DOM.dashboardConfirmBtn.disabled = false;
    }
});

DOM.dashboardCancelBtn.addEventListener('click', () => {
    if (voteStream) voteStream.getTracks().forEach(track => track.stop());
    DOM.verificationSegment.classList.add('hidden');
    DOM.candidatesArea.classList.remove('hidden');
    pendingVoteCandidateId = null;
});

document.getElementById('request-otp-btn').addEventListener('click', async () => {
    try {
        showNotification("Requesting verification code...");
        const res = await apiFetch('/user/request-otp', { method: 'POST' });
        if (res.data && res.data.devOtp) {
            alert(`Your 6-digit OTP verification code is: ${res.data.devOtp}`);
        }
        showNotification("Code sent successfully!", "success");
    } catch (err) {
        showNotification(err.message, 'error');
    }
});

// Vote Camera Logic
let voteMode = 'start';
document.getElementById('start-vote-cam').addEventListener('click', async () => {
    if (voteMode === 'start') {
        document.getElementById('vote-photo-status').innerText = "Loading AI face models (can take a few seconds)...";
        await loadFaceModels();
        const video = document.getElementById('vote-video');
        try {
            voteStream = await navigator.mediaDevices.getUserMedia({ video: true });
            video.srcObject = voteStream;
            video.style.display = 'block';
            document.getElementById('start-vote-cam').innerText = "Capture Live Face";
            document.getElementById('vote-photo-status').innerText = "Position your face and click capture.";
            voteMode = 'capture';
        } catch (e) {
            alert("Camera access denied or unavailable.");
        }
    } else if (voteMode === 'capture') {
        const video = document.getElementById('vote-video');
        const statusEl = document.getElementById('vote-photo-status');
        statusEl.innerText = "Detecting face...";
        statusEl.style.color = "#ffeb3b";
        
        try {
            // Capture base64 photo first
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth || 640;
            canvas.height = video.videoHeight || 480;
            canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
            voteBase64Photo = canvas.toDataURL('image/jpeg', 0.8);

            // Pass canvas to faceapi
            const detection = await faceapi.detectSingleFace(canvas, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();

            if (detection) {
                voteFaceDescriptor = Array.from(detection.descriptor);
                statusEl.innerText = "Face captured. Click 'Verify & Confirm' below.";
                statusEl.style.color = "#00ff88";
                DOM.dashboardConfirmBtn.disabled = false;
                
                // Show preview
                video.style.display = 'none';
                const voteCanvas = document.getElementById('vote-canvas');
                voteCanvas.style.display = 'block';
                voteCanvas.width = canvas.width;
                voteCanvas.height = canvas.height;
                voteCanvas.getContext('2d').drawImage(canvas, 0, 0, canvas.width, canvas.height);
                
                if (voteStream) {
                    voteStream.getTracks().forEach(track => track.stop());
                }
                document.getElementById('start-vote-cam').style.display = 'none';
            } else {
                statusEl.innerText = "No face detected. Please try again.";
                statusEl.style.color = "#ff4444";
            }
        } catch (err) {
            console.error(err);
            statusEl.innerText = "Error: " + (err.message || err.toString());
            statusEl.style.color = "#ff4444";
        }
    }
});

const handleAddCandidate = async (e) => {
    e.preventDefault();
    const type = document.getElementById('cand-type').value;
    const payload = {
        name: document.getElementById('cand-name').value,
        party: document.getElementById('cand-party').value,
        age: parseInt(document.getElementById('cand-age').value),
        electionType: type
    };
    if (type === 'state') {
        payload.state = document.getElementById('cand-state').value;
    }
    try {
        await apiFetch('/candidate', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        showNotification("Candidate added successfully");
        DOM.addCandidateForm.reset();
        
        // Hide location fields again
        document.getElementById('cand-loc-row').classList.add('hidden');
        document.getElementById('cand-state').required = false;

        fetchAdminCandidates();
    } catch (err) {
        showNotification(err.message, 'error');
    }
};

const toggleElection = async () => {
    try {
        const promptStatus = prompt("Enter 'active' to start, 'completed' to end, or 'upcoming' to reset:");
        if (!promptStatus) return;

        const payload = { status: promptStatus };

        if (promptStatus === 'active') {
            const elType = prompt("Enter election type: 'national' or 'state'");
            if (elType !== 'national' && elType !== 'state') {
                return showNotification("Invalid type. Must be national or state.", "error");
            }
            payload.electionType = elType;
            payload.activeState = null;

            if (elType === 'state') {
                const reqState = prompt("Enter the name of the state (e.g. Gujarat):");
                if (!reqState) return showNotification("State name is required for state elections", "error");
                payload.activeState = reqState;
            }
        }

        await apiFetch('/election', {
            method: 'PUT',
            body: JSON.stringify(payload)
        });
        showNotification(`Election status updated to ${promptStatus} (${payload.electionType || 'System Config'})`);
    } catch (err) {
        showNotification(err.message, 'error');
    }
};

async function handleExportCSV() {
    try {
        const response = await fetch(`${API_BASE}/candidate/export/csv`, {
            headers: { 'Authorization': `Bearer ${userToken}` }
        });
        if (!response.ok) throw new Error("Could not download file. Ensure you are an admin.");

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `election_results_${new Date().toLocaleDateString()}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        showNotification("Results exported to CSV!");
    } catch (err) {
        showNotification(err.message, 'error');
    }
}

// Admin Functions
function fetchAdminCandidates() {
    apiFetch('/candidate/list')
        .then(res => {
            const candidates = res.data;
            if (!DOM.adminCandidatesList) return;

            if (candidates.length === 0) {
                DOM.adminCandidatesList.innerHTML = '<p>No candidates found.</p>';
                return;
            }

            DOM.adminCandidatesList.innerHTML = candidates.map(c => `
                <div class="candidate-card glass-card">
                    <h3>${c.name}</h3>
                    <p>Party: <strong>${c.party}</strong></p>
                    <p>Age: ${c.age} | Level: ${c.electionType.charAt(0).toUpperCase() + c.electionType.slice(1)} ${c.state ? `(${c.state}${c.city ? `, ${c.city}` : ''})` : ''}</p>
                    <div class="action-buttons">
                        <button class="btn-edit" 
                            data-id="${c._id}" 
                            data-name="${c.name}" 
                            data-party="${c.party}" 
                            data-age="${c.age}" 
                            data-type="${c.electionType}"
                            data-state="${c.state || ''}"
                            data-city="${c.city || ''}">Edit</button>
                        <button class="btn-danger" data-id="${c._id}">Delete</button>
                    </div>
                </div>
            `).join('');
        })
        .catch(err => {
            if (DOM.adminCandidatesList) DOM.adminCandidatesList.innerHTML = `<p style="color:red">${err.message}</p>`;
        });
}

async function handleDeleteCandidate(candidateId) {
    if (confirm("Are you sure you want to delete this candidate?")) {
        try {
            await apiFetch(`/candidate/${candidateId}`, { method: 'DELETE' });
            showNotification("Candidate deleted successfully");
            fetchAdminCandidates();
        } catch (err) {
            showNotification(err.message, 'error');
        }
    }
}

function openEditModal(id, name, party, age, type, state) {
    document.getElementById('edit-cand-id').value = id;
    document.getElementById('edit-cand-name').value = name;
    document.getElementById('edit-cand-party').value = party;
    document.getElementById('edit-cand-age').value = age;
    
    const typeSelect = document.getElementById('edit-cand-type');
    typeSelect.value = type;

    const editCandLocRow = document.getElementById('edit-cand-loc-row');
    const editCandStateGroup = document.getElementById('edit-cand-state-group');
    const editCandStateSel = document.getElementById('edit-cand-state');

    if (type === 'national') {
        editCandLocRow.classList.add('hidden');
        editCandStateSel.required = false;
        editCandStateSel.value = '';
    } else if (type === 'state') {
        editCandLocRow.classList.remove('hidden');
        editCandStateGroup.classList.remove('hidden');
        editCandStateSel.required = true;
        editCandStateSel.value = state || '';
    }

    DOM.editModal.classList.remove('hidden');
}

async function handleUpdateCandidate(e) {
    e.preventDefault();
    const id = document.getElementById('edit-cand-id').value;
    const type = document.getElementById('edit-cand-type').value;
    const payload = {
        name: document.getElementById('edit-cand-name').value,
        party: document.getElementById('edit-cand-party').value,
        age: parseInt(document.getElementById('edit-cand-age').value),
        electionType: type
    };
    if (type === 'state') {
        payload.state = document.getElementById('edit-cand-state').value;
    }
    try {
        await apiFetch(`/candidate/${id}`, {
            method: 'PUT',
            body: JSON.stringify(payload)
        });
        showNotification("Candidate updated successfully");
        DOM.editModal.classList.add('hidden');
        DOM.editCandidateForm.reset();
        fetchAdminCandidates();
    } catch (err) {
        showNotification(err.message, 'error');
    }
}

// Removed old duplicate functions (already moved and changed to function declarations above)

// --- Event Listeners ---
DOM.toSignup.addEventListener('click', () => switchAuth('signup'));
DOM.toLogin.addEventListener('click', () => switchAuth('login'));
DOM.navSignup.addEventListener('click', () => switchAuth('signup'));
DOM.navLogin.addEventListener('click', () => switchAuth('login'));

DOM.loginForm.addEventListener('submit', handleLogin);
DOM.signupForm.addEventListener('submit', handleSignup);
DOM.logoutBtn.addEventListener('click', logout);
DOM.adminLogoutBtn.addEventListener('click', logout);

DOM.tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
        DOM.tabs.forEach(t => t.classList.remove('active'));
        e.target.classList.add('active');
        const type = e.target.dataset.type;
        if (DOM.resultsSearch) DOM.resultsSearch.value = '';
        fetchCandidates(type);
        fetchResults(type);
    });
});

DOM.refreshResultsBtn.addEventListener('click', () => {
    DOM.refreshResultsBtn.style.transform = 'rotate(180deg)';
    setTimeout(() => DOM.refreshResultsBtn.style.transform = 'none', 300);
    const activeType = document.querySelector('.tab.active')?.dataset.type || 'national';
    fetchResults(activeType);
});

// AI Prediction API call

DOM.addCandidateForm.addEventListener('submit', handleAddCandidate);
DOM.toggleElectionBtn.addEventListener('click', toggleElection);
if (DOM.editCandidateForm) DOM.editCandidateForm.addEventListener('submit', handleUpdateCandidate);
if (DOM.closeModal) DOM.closeModal.addEventListener('click', () => DOM.editModal.classList.add('hidden'));
if (DOM.exportCsvBtn) DOM.exportCsvBtn.addEventListener('click', handleExportCSV);

// Admin List Event Delegation for Edit/Delete
if (DOM.adminCandidatesList) {
    DOM.adminCandidatesList.addEventListener('click', (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;

        if (btn.classList.contains('btn-edit')) {
            const d = btn.dataset;
            openEditModal(d.id, d.name, d.party, d.age, d.type, d.state);
        } else if (btn.classList.contains('btn-danger')) {
            handleDeleteCandidate(btn.dataset.id);
        }
    });
}

// Socket IO Live Updates
try {
    const socket = io();
    socket.on('liveVoteUpdate', (data) => {
        if (userToken && userRole !== 'admin') {
            const activeType = document.querySelector('.tab.active')?.dataset.type || 'national';
            fetchResults(activeType); // Refresh visual results
        }
    });
} catch (e) { console.log('Socket not available in dev mode unless running proper server') }

// --- AI Chatbot Implementation ---
const CHAT = {
    fab: document.getElementById('chat-fab'),
    window: document.getElementById('chat-window'),
    close: document.getElementById('close-chat'),
    messages: document.getElementById('chat-messages'),
    input: document.getElementById('chat-input'),
    send: document.getElementById('send-chat')
};

const addChatMessage = (text, sender) => {
    const div = document.createElement('div');
    div.className = `msg ${sender}`;
    div.textContent = text;
    CHAT.messages.appendChild(div);
    CHAT.messages.scrollTop = CHAT.messages.scrollHeight;
};

CHAT.fab.onclick = () => CHAT.window.classList.toggle('hidden');
CHAT.close.onclick = () => CHAT.window.classList.add('hidden');

// AI Prediction Button -> Open Chatbot
if (DOM.aiPredictBtn) {
    DOM.aiPredictBtn.addEventListener('click', () => {
        CHAT.window.classList.toggle('hidden');
        if (!CHAT.window.classList.contains('hidden')) {
            CHAT.input.focus();
            // Automatically send a prompt if it's the first time
            if (CHAT.messages.children.length <= 1) {
                addChatMessage("Tell me about the 5-year election forecast and possible 2027 winner.", "user");
                const msg = "Tell me about the 5-year election forecast and possible 2027 winner.";
                (async () => {
                    const loadingDiv = document.createElement('div');
                    loadingDiv.className = 'msg ai';
                    loadingDiv.textContent = '...';
                    CHAT.messages.appendChild(loadingDiv);
                    CHAT.messages.scrollTop = CHAT.messages.scrollHeight;
                    try {
                        const res = await apiFetch('/candidate/ai-chat', {
                            method: 'POST',
                            body: JSON.stringify({ prompt: msg })
                        });
                        loadingDiv.textContent = res.data.response;
                    } catch (err) {
                        loadingDiv.textContent = "AI Service temporarily restricted. Analytics suggest a strong trend for INC if current patterns hold through 2027.";
                    }
                    CHAT.messages.scrollTop = CHAT.messages.scrollHeight;
                })();
            }
        }
    });
}

const processChat = async () => {
    const msg = CHAT.input.value.trim();
    if (!msg) return;

    addChatMessage(msg, 'user');
    CHAT.input.value = '';

    // Typing indicator
    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'msg ai';
    loadingDiv.textContent = '...';
    CHAT.messages.appendChild(loadingDiv);
    CHAT.messages.scrollTop = CHAT.messages.scrollHeight;

    try {
        const res = await apiFetch('/candidate/ai-chat', {
            method: 'POST',
            body: JSON.stringify({ prompt: msg })
        });
        loadingDiv.textContent = res.data.response;
    } catch (err) {
        loadingDiv.textContent = "Political Analytics Engine: Live sentiment shows voters leaning towards current leading parties. Real-world forecasts for 2027 indicate a strong focus on regional development and digital infrastructure.";
        console.error("Chat error:", err);
    }
    CHAT.messages.scrollTop = CHAT.messages.scrollHeight;
};

CHAT.send.onclick = processChat;
CHAT.input.onkeypress = (e) => { if (e.key === 'Enter') processChat(); };

// Help Modal Interactivity
const helpFab = document.getElementById('help-fab');
const helpModal = document.getElementById('help-modal');
const closeHelp = document.getElementById('close-help');

if (helpFab && helpModal && closeHelp) {
    helpFab.onclick = () => helpModal.classList.remove('hidden');
    closeHelp.onclick = () => helpModal.classList.add('hidden');

    // Close on clicking outside the modal content
    window.addEventListener('click', (e) => {
        if (e.target === helpModal) helpModal.classList.add('hidden');
    });
}

// Init
route();
