const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/user');

dotenv.config();

async function run() {
    try {
        const uri = process.env.MONGO_URL;
        console.log(`Connecting to ${uri}...`);
        await mongoose.connect(uri);
        console.log('Connected!');

        const users = await User.find();
        console.log('Users in DB:');
        console.log(JSON.stringify(users.map(u => ({
            name: u.name,
            aadhar: u.aadharCardNumber,
            role: u.role,
            state: u.state,
            city: u.city
        })), null, 2));

        await mongoose.disconnect();
        console.log('Disconnected!');
    } catch (e) {
        console.error(e);
    }
}

run();
