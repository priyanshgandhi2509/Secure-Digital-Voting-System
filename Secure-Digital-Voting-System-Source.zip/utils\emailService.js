const nodemailer = require('nodemailer');

const sendEmail = async (to, subject, text, html) => {
  try {
    // Note: To use Gmail, you need to create an "App Password" 
    // and set EMAIL_USER and EMAIL_PASS in your .env file.
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    const mailOptions = {
      from: `"Vooting System" <${process.env.EMAIL_USER}>`,
      to,
      subject,
      text,
      html
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Email sent: ' + info.messageId);
    return info;
  } catch (error) {
    if (error.code === 'EAUTH' || (error.message && error.message.includes('BadCredentials'))) {
      console.warn('⚠️ Email notification skipped: Invalid or expired email credentials (EMAIL_USER/EMAIL_PASS) in .env');
    } else {
      console.error('❌ Email sending failed:', error.message || error);
    }
    // Even if it fails, we log it so the user can see it in development
    return null;
  }
};

module.exports = sendEmail;
