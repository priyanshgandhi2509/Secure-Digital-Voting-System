const mongoose = require('mongoose');
const { type } = require('node:os');
const User = require('./user');
// const bcrypt = require('bcrypt');

// Define the Person schema
const candidateSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  party:{
    type:String,
    required: true
  },
  age: {
    type: Number,
    required: true
  },
  votes:[
    {
      User:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
      },
      votedAt:{
        type:Date,
        default:Date.now
      },
      voterState: { 
        type: String, 
        required: true 
      },
      voterCity: { 
        type: String, 
        required: false 
      }
    }
  ],
  state: {
    type: String,
    required: function() { return this.electionType === 'state'; }
  },
  city: {
    type: String,
    required: false
  },
  electionType: {
    type: String,
    enum: ['national', 'state'],
    required: true,
    index: true
  },
  voteCount:{
    type:Number,
    default:0
  }
}, { timestamps: true });

const Candidate = mongoose.models.Candidate || mongoose.model('Candidate', candidateSchema);
module.exports = Candidate;